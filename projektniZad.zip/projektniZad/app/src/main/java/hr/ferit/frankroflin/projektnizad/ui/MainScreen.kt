package hr.ferit.frankroflin.projektnizad.ui

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import hr.ferit.frankroflin.projektnizad.R

@Preview(showBackground = true)
@Composable
fun MainScreen(){
    Column {
        LaneDescriptionRight(R.drawable.toplane, "TOPLANE")
        LaneDescriptionLeft(R.drawable.jungle, "JUNGLE")
        LaneDescriptionRight(R.drawable.mid, "MIDLANE")
        LaneDescriptionLeft(R.drawable.adc, "ADC")
        LaneDescriptionRight(R.drawable.supp, "SUPPORT")
    }
}

@Composable
fun LaneDescriptionRight(
    @DrawableRes imageResource: Int,
    laneTitle: String
){
    Row (
        horizontalArrangement=Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
        modifier=Modifier
            .width(320.dp)
    ){
        Image(
            modifier= Modifier
                .width(90.dp)
                .height(90.dp),
            painter = painterResource(id = imageResource),
            contentDescription = null)

        Column(
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .width(211.dp)
        ) {
            Text(
                text = laneTitle,
                style = TextStyle(
                    fontSize = 16.sp,
                    fontWeight = FontWeight(400),
                    color = Color(0xFF000000),
                )
            )
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .background(
                        color = Color(0xFFD9D9D9),
                        shape = RoundedCornerShape(size = 15.dp)
                    )


            )
            {
                Text(
                    text = "Opis uloge kada lejnaš na topu",
                    textAlign = TextAlign.Center,
                    style = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight(400),
                        color = Color(0xFF000000),
                    )
                )
            }
        }
    }
}

@Composable
fun LaneDescriptionLeft(
    @DrawableRes imageResource: Int,
    laneTitle: String
){
    Row (
        horizontalArrangement=Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
        modifier=Modifier
            .width(320.dp)
    ){


        Column(
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .width(211.dp)
        ) {
            Text(
                text = laneTitle,
                style = TextStyle(
                    fontSize = 16.sp,
                    fontWeight = FontWeight(400),
                    color = Color(0xFF000000),
                )
            )
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .background(
                        color = Color(0xFFD9D9D9),
                        shape = RoundedCornerShape(size = 15.dp)
                    )


            )
            {
                Text(
                    text = "Opis uloge kada lejnaš na topu",
                    textAlign = TextAlign.Center,
                    style = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight(400),
                        color = Color(0xFF000000),
                    )
                )
            }
        }
        Image(
            modifier= Modifier
                .width(90.dp)
                .height(90.dp),
            painter = painterResource(id = imageResource),
            contentDescription = null)
    }
}